package com.example.alquran

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
